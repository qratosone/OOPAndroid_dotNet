﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wizard
{
    public class Info
    {
        public Info() { }
        public string name = "";
        public string mail = "";
        public string age = "";
    }
}
